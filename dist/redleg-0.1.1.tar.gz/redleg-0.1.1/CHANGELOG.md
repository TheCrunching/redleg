# Changelog

This is the changelog for RedLog a simple ledger application.

## [0.1.1] - 2025-07-14

### Fixed

- Fixed how I implemented the account equation

### Changed

- Changed the logging format
- Changed the date format

## [0.1.0] - 2025-07-13

_Initial release_

[0.1.0]: https://github.com/TheCrunching/RedLeg/releases/tag/v0.1.0
