# TODO

## Redleg

Simple dual entry ledger program.

### Todo

- [ ] Make sure any date that is entered is not in the future
- [ ] Consider encrypting the ledger file
- [ ] Uses *curses* to make it more interactive

### In progress

### Completed
